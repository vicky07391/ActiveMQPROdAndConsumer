package com.vivek.customercommand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

/**
 * Created by ben on 19/01/16.
 */

@SpringBootApplication
//@ComponentScan(value = "com.vivek.customercommand")
public class CommandSide {

    public static void main(String... args) {
        ApplicationContext context = SpringApplication.run(CommandSide.class, args);
//        SpringApplication.run(CommandSide.class, args);
//        ApplicationContext ctx = new SpringApplicationBuilder().bannerMode(Banner.Mode.CONSOLE).run(args);

    }
}

/*@RestController
class ServiceInstanceRestController {

    @Autowired
    private DiscoveryClient discoveryClient;

    @Value("${spring.application.name}")
    private String appName;

    @RequestMapping("/instances")
    public List<ServiceInstance> serviceInstancesByApplicationName() {
        return this.discoveryClient.getInstances(appName);
    }
}


@RefreshScope
@RestController
class MessageRestController {

    @Value("${message}")
    private String message;

    @RequestMapping("/message")
    String getMessage() {
        return this.message;
    }
}*/
