package com.vivek.customercommand.aggregates;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.eventsourcing.annotation.AbstractAnnotatedAggregateRoot;
import org.axonframework.eventsourcing.annotation.AggregateIdentifier;
import org.axonframework.eventsourcing.annotation.EventSourcingHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vivek.customercommand.commands.AddCustomerCommand;
import com.vivek.customercommand.events.CustomerAddedEvent;

public class CustomerAggregate extends AbstractAnnotatedAggregateRoot{

	private static final Logger LOG = LoggerFactory.getLogger(CustomerAggregate.class);
	
	@AggregateIdentifier
	private  String id;
	private  String name;
	
	
	public CustomerAggregate(){
		
	}
	
	@CommandHandler
	public CustomerAggregate(AddCustomerCommand command){
		LOG.debug("Command: 'AddCustomerCommand' received.");
        LOG.debug("Queuing up a new CustomerAddedEvent for product '{}'", command.getId());
        apply(new CustomerAddedEvent(command.getId(), command.getName()));
	}
	
	@EventSourcingHandler
	public void on(CustomerAddedEvent event){
		this.id = event.getId();
		this.name = event.getName();
        LOG.debug("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(), event.getName());
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	
}
