package com.vivek.customercommand.commands;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;

public class AddCustomerCommand {

	
	  	@TargetAggregateIdentifier
	    private final String id;
	    private final String name;
	    
	    public AddCustomerCommand(String id, String name){
	    	this.id = id;
	    	this.name = name;
	    }

		public String getId() {
			return id;
		}

		public String getName() {
			return name;
		}
	    
	    
	    
}
