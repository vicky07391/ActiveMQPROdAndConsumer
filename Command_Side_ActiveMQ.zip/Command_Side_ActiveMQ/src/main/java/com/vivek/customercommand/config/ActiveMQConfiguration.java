package com.vivek.customercommand.config;

import javax.jms.ConnectionFactory;

import org.apache.activemq.spring.ActiveMQConnectionFactory;
//import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.MessageListenerContainer;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.SimpleMessageConverter;


@Configuration
public class ActiveMQConfiguration {

//	private static final String DEFAULT_BROKER_URL = "tcp://localhost:61616";

	private static final String DEFAULT_BROKER_URL = "tcp://0.0.0.0:61613";

	
	
	private static final String ORDER_QUEUE = "order-queue";
	private static final String ORDER_RESPONSE_QUEUE = "order-response-queue";
	
	@Autowired
	MessageReceiver messageReceiver;

	
   /* @Value("${spring.rabbitmq.hostname}")
    private String hostname;

    @Value("${spring.rabbitmq.username}")
    private String username;

    @Value("${spring.rabbitmq.password}")
    private String password;


    @Value("${spring.application.queue}")
    private String queueName;*/

    /*@Bean
    Queue defaultStream() {
        return new Queue(ORDER_QUEUE, true);
    }*/
    
    
    @Bean
    ConnectionFactory connectionFactory(){
    	ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory();
    	activeMQConnectionFactory.setBrokerURL(DEFAULT_BROKER_URL);
    	return activeMQConnectionFactory;
    }
    
    @Bean
	public ConnectionFactory cachingConnectionFactory(){
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
		connectionFactory.setTargetConnectionFactory(connectionFactory());
		connectionFactory.setSessionCacheSize(10);
		return connectionFactory;
	}
    
    
	@Bean
	public MessageListenerContainer getContainer(){
		DefaultMessageListenerContainer container = new DefaultMessageListenerContainer();
		container.setConnectionFactory(connectionFactory());
		container.setDestinationName(ORDER_RESPONSE_QUEUE);
		container.setMessageListener(messageReceiver);
		return container;
	}

	/*
	 * Used here for Sending Messages.
	 */
	@Bean 
	public JmsTemplate jmsTemplate(){
		JmsTemplate template = new JmsTemplate();
		template.setConnectionFactory(connectionFactory());
		template.setDefaultDestinationName(ORDER_QUEUE);
		return template;
	}
	
	
	
	
	@Bean 
	MessageConverter converter(){
		return new SimpleMessageConverter();
	}
}

