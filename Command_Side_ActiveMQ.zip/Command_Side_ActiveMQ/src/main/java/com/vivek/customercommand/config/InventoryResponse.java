package com.vivek.customercommand.config;

import java.io.Serializable;

public class InventoryResponse implements Serializable{

	
	@Override
	public String toString() {
		return "InventoryResponse [ SUCCCCESSS" + "]";
	}


	
}
