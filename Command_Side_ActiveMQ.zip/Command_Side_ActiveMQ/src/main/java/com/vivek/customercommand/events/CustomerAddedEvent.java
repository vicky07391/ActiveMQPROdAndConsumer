package com.vivek.customercommand.events;

public class CustomerAddedEvent extends AbstractEvent{

	private String name;

	public CustomerAddedEvent() {
	}

	public CustomerAddedEvent(String id, String name) {
		super(id);
		this.name = name;
	}

	public String getName() {
		return name;
	}

}
