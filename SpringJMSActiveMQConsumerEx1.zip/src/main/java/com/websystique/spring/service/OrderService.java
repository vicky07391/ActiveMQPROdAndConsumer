package com.websystique.spring.service;

import com.websystique.spring.model.Product;

public interface OrderService {

	public void processOrder(Product product);
}
