package com.websystique.spring.service;

import com.websystique.spring.model.Product;

public interface ProductService {

	public void sendProduct(Product product);
	
	
}
